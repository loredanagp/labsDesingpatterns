export type ISubscription<T> = (prev: T, current: T) => void;

export interface ISubscribable {
    subscribe: (subscription: ISubscription<any>) => () => void
}