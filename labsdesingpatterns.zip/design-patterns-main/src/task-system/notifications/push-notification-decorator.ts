import { INotificationProps } from "./types";
import { NotificationDecorator } from "./notifications-decorator";
import { PushNotification } from "./push-notification";

export class PushNotificationDecorator extends NotificationDecorator {
    private service = new PushNotification(null);

    send(props: INotificationProps) {
        this.service.send(props);
        super.send(props);
    }
}