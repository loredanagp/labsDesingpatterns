import { NotificationDecorator } from "./notifications-decorator";
import { SmsNotification } from "./sms-notification";
import { INotificationProps } from "./types";

export class SmsNotificationDecorator extends NotificationDecorator {
    private service = new SmsNotification(null);

    send(props: INotificationProps) {
        this.service.send(props);
        super.send(props);
    }
}