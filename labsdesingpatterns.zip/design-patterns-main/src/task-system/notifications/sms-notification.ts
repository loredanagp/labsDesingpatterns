import { INotification, INotificationProps } from "./types";

export class SmsNotification implements INotification {
    system: any

    constructor(smsNotificationDependency: any) {
        // Some fancy setup for push notifications
        this.system = {
            MakeSmsRequest: (props: INotification) => null
        };
    }

    send(props: INotificationProps): void {
        this.system.MakeSmsRequest(props);
        console.log(`Notified ${props.to} about "${props.title}" via SMS`);
    }
}