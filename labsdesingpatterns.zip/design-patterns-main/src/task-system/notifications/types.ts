export interface INotification {
    send(props: INotificationProps): void;
}

export enum NotificationType {
    sms,
    email,
    push
};

export interface INotificationProps {
    title: string,
    description: string;
    to: string;
}