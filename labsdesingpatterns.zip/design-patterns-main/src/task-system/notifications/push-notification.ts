import { INotification, INotificationProps } from "./types";

export class PushNotification implements INotification {
    system: any

    constructor(pushNotificationDependency: any) {
        // Some fancy setup for push notifications
        this.system = {
            MakePushRequest: (props: INotification) => null
        };
    }

    send(props: INotificationProps): void {
        this.system.MakePushRequest(props);
        console.log(`Notified ${props.to} about "${props.title}" via Push`);
    }
}