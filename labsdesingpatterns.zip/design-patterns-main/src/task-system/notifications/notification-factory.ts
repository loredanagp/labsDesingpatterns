import { INotification, INotificationProps, NotificationType } from './types';
import { EmailNotification } from './email-notification';
import { SmsNotification } from './sms-notification';
import { PushNotification } from './push-notification';
import { EmailNotificationDecorator } from './email-notification-decorator';

export class NotificationFactory {
    createEmailNotificationService(): INotification {
        const EmailDependency = null;
        return new EmailNotification(EmailDependency);
    }
    createSMSNotificationService(): INotification {
        const SMSdependency = null;
        return new SmsNotification(SMSdependency);
    }
    createPushotificationService(): INotification {
        const PushDependency = null;
        return new PushNotification(PushDependency);
    }

    // We will consider the push notification as default
    createCombinedNotificationService(types: NotificationType[]): INotification {
        let base = this.createPushotificationService();

        if (types.includes(NotificationType.email)) {
            base = new EmailNotificationDecorator(base);
        }

        if (types.includes(NotificationType.sms)) {
            base = new EmailNotificationDecorator(base);
        }

        return base;
    }
}
