import { NotificationDecorator } from "./notifications-decorator";
import { EmailNotification } from "./email-notification";
import { INotificationProps } from "./types";

export class EmailNotificationDecorator extends NotificationDecorator {
    private service = new EmailNotification(null);

    send(props: INotificationProps) {
        this.service.send(props);
        super.send(props);
    }
}