export interface ITeamLeads {
    qa: string,
    frontEnd: string,
    backEnd: string
}