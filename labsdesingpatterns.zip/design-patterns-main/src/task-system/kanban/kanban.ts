import { ITask } from '../tasks/types';
import { NotificationFactory } from '../notifications/notification-factory';
import { NotificationType } from '../notifications/types';

export class Kanban {
    private notification = new NotificationFactory().createCombinedNotificationService([NotificationType.email, NotificationType.sms]);
    private tasks: ITask[] = [];

    constructor() {
    }

    getTasksByAsignee(asignee: string) {
        return this.tasks.filter(task => task.asignee === asignee) || [];
    }

    getTasksById(ids: number[]) {
        return this.tasks.filter(task => ids.includes(task.id));
    }

    addTask(task: ITask): void {
        task.setSubtasksGetter(this.getTasksById);
        this.tasks.push(task);
        this.notification.send({
            to: task.asignee,
            title: `New Issue: ${task.name}`,
            description: task.description
        })
    }
}