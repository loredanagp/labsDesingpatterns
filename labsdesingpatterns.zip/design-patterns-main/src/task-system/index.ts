import { TaskSystemProxy} from './system-proxy/system-proxy';
export default TaskSystemProxy;