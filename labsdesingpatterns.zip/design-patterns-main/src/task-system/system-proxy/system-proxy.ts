import { TaskSystem } from '../tasks/task-system';
import { ITaskSystem } from '../tasks/types';
import { ITeamLeads } from '../teams/types';
import { IUserList, SystemUserType } from './types';
import { UserHandlerBuilder, IUserHandler } from './user-cos';

export class TaskSystemProxy implements ITaskSystem {
    private static instance: TaskSystemProxy;
    private taskSystem: TaskSystem;
    private users: IUserList = {
        '#bda': SystemUserType.admin,
        '#asd': SystemUserType.projectOwner
    }

    private checkIfAdmin: IUserHandler;
    private checkIfPo: IUserHandler;

    private currentUser = '';

    private constructor() {
        this.taskSystem = TaskSystem.getInstance();

        this.checkIfAdmin = UserHandlerBuilder.getInstance(this.users, SystemUserType.admin);
        this.checkIfPo = UserHandlerBuilder.getInstance(this.users, SystemUserType.projectOwner);
    }

    public static getInstance(): TaskSystemProxy {
        if (!TaskSystemProxy.instance) {
            TaskSystemProxy.instance = new TaskSystemProxy();
        }

        return TaskSystemProxy.instance;
    }

    setTeamLeads(teamLeads: ITeamLeads): void {
        if (!this.checkIfAdmin.execute(this.currentUser)) {
            console.log('Access denied!')
            return;
        }

        this.taskSystem.setTeamLeads(teamLeads);
    }

    reportBug(name: string, description: string, ...subtasksNames: string[]): void {
        if (!this.checkIfPo.execute(this.currentUser)) {
            console.log('Access denied!')
            return;
        }
        this.taskSystem.reportBug(name, description, ...subtasksNames);
    }

    requestFeature(name: string, description: string, ...subtasksNames: string[]): void {
        if (!this.checkIfPo.execute(this.currentUser)) {
            console.log('Access denied!')
            return;
        }
        this.taskSystem.requestFeature(name, description, ...subtasksNames);
    }

    authoriseAndRun(user: string, fn: () => void) {
        this.currentUser = user;
        fn();
        this.currentUser = '';
    }
}