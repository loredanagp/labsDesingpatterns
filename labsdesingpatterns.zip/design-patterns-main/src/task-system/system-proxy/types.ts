export enum SystemUserType {
    admin,
    projectOwner
}

export interface IUserList {
    [key: string]: SystemUserType
}