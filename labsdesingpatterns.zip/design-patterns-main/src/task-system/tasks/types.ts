import { ITeamLeads } from "../teams/types";
import { ISubscribable } from "../utils/types";

export enum TaskType {
    feature = 'feature',
    layout = 'layout',
    bugfix = 'bugfix',
    qa = 'qa',
    subtask = 'subtask',
    other = 'other'
}

export type SubtasksGetter = (ids: number[]) => ITask[];

export enum TaskStatus {
    backlock,
    todo,
    inProgress,
    codeReview,
    readyForQa,
    done
}

export interface ITaskSystem {
    setTeamLeads: (teamLeads: ITeamLeads) => void;
    reportBug: (name: string, description: string, ...subtasksNames: string[]) => void;
    requestFeature: (name: string, description: string, ...subtasksNames: string[]) => void
}

export interface ITask extends ISubscribable {
    id: number;
    type: TaskType;
    name: string;
    description: string;
    asignee: string;
    setSubtasksGetter: (fn: SubtasksGetter) => void;
    addSubtask: (id: number) => void;
    getEstimation: () => number
    subtasks?: number[];
    status: TaskStatus;
}

export interface ITaskChanges {
    type?: TaskType,
    name?: string;
    description?: string;
    asignee?: string;
    status?: TaskStatus
}