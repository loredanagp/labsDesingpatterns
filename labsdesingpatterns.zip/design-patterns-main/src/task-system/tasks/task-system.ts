import { ITask, ITaskSystem } from './types';
import { TaskBuilder } from './task-builder';
import { ITeamLeads } from '../teams/types';
import { Kanban } from '../kanban/kanban';

// Singleton
export class TaskSystem implements ITaskSystem {
    private static instance: TaskSystem;
    private constructor() {
        this.TaskBuilder = new TaskBuilder();
        this.kanban = new Kanban();
    }
    public static getInstance(): TaskSystem {
        if (!TaskSystem.instance) {
            TaskSystem.instance = new TaskSystem();
        }

        return TaskSystem.instance;
    }

    private kanban: Kanban;
    private TaskBuilder: TaskBuilder;

    getCanban(): Kanban {
        return this.kanban;
    }

    setTeamLeads(teamLeads: ITeamLeads): void {
        this.TaskBuilder.teamLeads = teamLeads;
    }

    reportBug(name: string, description: string, ...subtasksNames: string[]): void {
        console.log('System, please make a bug task')
        console.log();
        const task = this.TaskBuilder.createBugTask();
        task.name = name;
        task.description = description;
        this.kanban.addTask(task);

        this.addSubtasks(task, subtasksNames);
    }

    requestFeature(name: string, description: string, ...subtasksNames: string[]): void {
        console.log('System, we have a new feature to develop!')
        console.log();
        const backTask = this.TaskBuilder.createFeatureTask();
        backTask.subscribe((prev, curr) => {
            prev = JSON.stringify(prev);
            curr = JSON.stringify(curr);
            console.log(`Change detected: ${prev}, ${curr}`)
        })
        backTask.name = name;
        backTask.description = description;
        this.kanban.addTask(backTask);

        const frontTask = this.TaskBuilder.createLayoutTask();
        frontTask.name = `Layout for ${name}`;
        frontTask.description = description;
        this.kanban.addTask(frontTask);
        
        this.addSubtasks(backTask, subtasksNames);
    }

    private addSubtasks(parent: ITask, subtasksNames:string[]): void {
        subtasksNames.map(taskName => {
            const subtask = this.TaskBuilder.createSubtask(parent);
            subtask.name = taskName;

            parent.addSubtask(subtask.id);
            return subtask;
        }).forEach(subtask => this.kanban.addTask(subtask));
    }
}

