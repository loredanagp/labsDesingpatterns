import { ITask } from './types';
import { TaskType } from './types';
import { ITeamLeads } from '../teams/types';
import { Task } from './task';
import { ISubscribable, ISubscription } from '../utils/types';

export class TaskBuilder {
    teamLeads: ITeamLeads = {
        qa: '',
        frontEnd: '',
        backEnd: ''
    };
    
    constructor(teamLeads?: ITeamLeads) {
        this.task = new Task(this.counter++);
    }

    private counter = 0;
    private task: Task;

    private reset(): void {
        this.task = new Task(this.counter++);
    }

    private getNewTaskInstance(): Task {
        const res = this.task;
        this.reset();
        return res;
    }

    createBugTask(): ITask {
        const res = this.getNewTaskInstance();
        res.type = TaskType.bugfix;
        res.asignee = this.teamLeads.qa;
        console.log(`Creating Bug task`);

        return res;
    }

    createFeatureTask(): ITask {
        const res = this.getNewTaskInstance();
        res.type = TaskType.feature;
        res.asignee = this.teamLeads.backEnd;
        console.log(`Creating Feature task`);

        return res;
    }

    createLayoutTask(): ITask {
        const res = this.getNewTaskInstance();
        res.type = TaskType.layout;
        res.asignee = this.teamLeads.frontEnd;
        console.log(`Creating Layout task`);

        return res;
    }

    createSubtask(parent: ITask): ITask {
        const res = this.getNewTaskInstance();
        res.type = TaskType.subtask;
        res.asignee = parent.asignee;
        console.log(`Created new subtask from ${parent.name}`);

        return res;
    }
}