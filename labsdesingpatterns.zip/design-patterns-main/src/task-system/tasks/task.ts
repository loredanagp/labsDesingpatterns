import { ITask, TaskType, TaskStatus, SubtasksGetter, ITaskChanges } from "./types";
import { Observable } from '../utils/observable'
import { ISubscribable, ISubscription } from "../utils/types";

export class Task implements ITask, ISubscribable {
    private subtaskGetter: SubtasksGetter = () => [];
    private estimation = 0;
    private _subtasks: number[] = [];
    private observable: Observable<ITaskChanges>;
    id: number = 0;
    type: TaskType = TaskType.other;

    private _name: string = '';
    public get name(): string {
        return this._name;
    } public set name(val: string) {
        this.observable.emit({name: this.name}, {name: val});
        this._name = val;
    }

    private _description: string = '';
    public get description(): string {
        return this._description;
    } public set description(val: string) {
        this.observable.emit({description: this.description}, {description: val});
        this._description = val;
    }
    
    private _asignee: string = '';
    public get asignee(): string {
        return this._asignee;
    } public set asignee(val: string) {
        this.observable.emit({asignee: this.asignee}, {asignee: val});
        this._asignee = val;
    }

    private _status = TaskStatus.backlock;
    public get status(): TaskStatus {
        return this._status;
    } public set status(val: TaskStatus) {
        this.observable.emit({status: this.status}, {status: val});
        this._status = val;
    }

    constructor(id: number) {
        this.id = id;
        this.observable = new Observable<ITaskChanges>();
    }

    get subtasks(): number[] {
        return this._subtasks;
    }

    addSubtask(id: number) {
        if (!this.subtasks.includes(id)) {
            this.subtasks.push(id);
        }
    }

    setSubtasksGetter(subtasksGetter: SubtasksGetter) {
        this.subtaskGetter = subtasksGetter;
    }

    getSubtaskInstances(): ITask[] {
        return this.subtaskGetter(this.subtasks);
    }

    getEstimation(): number {
        const subtasksEstimation = this.getSubtaskInstances()
            .map(task => task.getEstimation())
            .reduce((accumulator, current) => accumulator + current);
        
        if (this.status = TaskStatus.done) {
            return subtasksEstimation;
        }
        return this.estimation + subtasksEstimation;
    }

    subscribe(subscription: ISubscription<ITaskChanges>) {
        return this.observable.subscribe(subscription);
    }
}