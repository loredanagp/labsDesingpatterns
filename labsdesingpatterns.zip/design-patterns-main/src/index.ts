import { Client } from './client';

const client = new Client();
client.run();